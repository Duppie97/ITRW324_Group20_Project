A Pen created at CodePen.io. You can find this one at http://codepen.io/ehermanson/pen/KwKWEv.

 A design for a sign-up/login form using tabs and floating form labels.